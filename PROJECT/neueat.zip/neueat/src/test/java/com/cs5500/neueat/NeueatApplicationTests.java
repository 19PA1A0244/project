package com.cs5500.neueat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeueatApplicationTests {

	@Test
	void contextLoads() {
	}

}
