package com.cs5500.NEUeat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NEUeatApplication {

	public static void main(String[] args) {
		SpringApplication.run(NEUeatApplication.class, args);
	}
}
