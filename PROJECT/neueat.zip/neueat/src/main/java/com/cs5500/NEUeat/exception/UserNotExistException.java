package com.cs5500.NEUeat.exception;

public class UserNotExistException extends Exception {

  public UserNotExistException(String message) {
    super(message);
  }
}
