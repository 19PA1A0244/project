package com.cs5500.NEUeat.exception;

public class PasswordNotMatchException extends Exception {

  public PasswordNotMatchException(String message) {
    super(message);
  }
}
