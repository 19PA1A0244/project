package com.cs5500.NEUeat.exception;

public class DishNotExistException extends Exception {

  public DishNotExistException(String message) {
    super(message);
  }
}
