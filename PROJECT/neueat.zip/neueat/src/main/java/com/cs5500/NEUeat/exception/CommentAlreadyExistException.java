package com.cs5500.NEUeat.exception;

public class CommentAlreadyExistException extends Exception {

  public CommentAlreadyExistException(String message) {
    super(message);
  }
}
