package com.cs5500.NEUeat.exception;

public class OrderNotFinishedException extends Exception {

  public OrderNotFinishedException(String message) {
    super(message);
  }
}
